# Building System Identification

A Python library for system identification of building models.

## Installation

```bash
pip install buildingsysid